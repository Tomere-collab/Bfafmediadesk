# BFAF Media Desk — Netlify edition

Next.js media accreditation application portal for the Bayelsa Food & Art Festival.

## Deploy to Netlify
1. Upload this project to a GitHub repository, or import the repository directly into Netlify.
2. In Netlify, choose **Add new project → Import an existing project** and connect the GitHub repository.
3. Netlify should detect Next.js. The included `netlify.toml` sets `npm run build`, `.next`, and the official Next.js runtime plugin.
4. Before accepting real applications, create a Supabase project and run `supabase/schema.sql` in its SQL Editor.
5. In Netlify, open **Site configuration → Environment variables** and add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
6. Trigger a fresh deploy after adding the environment variables.

## Local development
- Install Node.js (20 or newer recommended).
- Run `npm install`.
- Copy `.env.example` to `.env.local` and enter the Supabase values.
- Run `npm run dev`.

## Important
- Keep `SUPABASE_SERVICE_ROLE_KEY` private. Never expose it in browser code or add a `NEXT_PUBLIC_` prefix.
- Applications are stored with status `Under review`. The portal does not automatically approve or reject applicants; the BFAF team makes accreditation decisions.
- This starter stores applications in Supabase. It does not yet send email notifications to Gmail and does not include the internal reviewer dashboard.
- Netlify's Next.js runtime handles the Next.js page and API route; do not change the project into a static export.
